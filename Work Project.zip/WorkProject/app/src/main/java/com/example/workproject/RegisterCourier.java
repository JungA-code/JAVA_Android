package com.example.workproject;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class RegisterCourier extends AppCompatActivity {

    SQLiteDatabase sqlitedb;
    DBHelper dbHelper;
    String tableName = "deliverty";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deliverty);

        setTitle("등록 ");

        Intent it = getIntent();

        String str_waybillNum = it.getStringExtra("it_waybillnum");
        String str_name = it.getStringExtra("it_name");
        String str_phone = it.getStringExtra("it_phone");
        String str_status = it.getStringExtra("it_status");
        String str_product = it.getStringExtra("it_product");

        ImageView product = (ImageView) findViewById(R.id.product);

        if(str_product.equals("생필품")){
          BitmapDrawable product1 = (BitmapDrawable)getResources().getDrawable(R.drawable.product1);
          product.setImageDrawable(product1); }
        else if(str_product.equals("잡화")){
            BitmapDrawable product2 = (BitmapDrawable)getResources().getDrawable(R.drawable.product2);
            product.setImageDrawable(product2); }
        else if(str_product.equals("의류")){
            BitmapDrawable product3 = (BitmapDrawable)getResources().getDrawable(R.drawable.product3);
            product.setImageDrawable(product3); }
        else if(str_product.equals("취급주의")){
            BitmapDrawable product4 = (BitmapDrawable)getResources().getDrawable(R.drawable.product4);
            product.setImageDrawable(product4); }

        try {
            dbHelper = new DBHelper(this, DBHelper.tableName, null, 1);

            sqlitedb = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("product", str_product);
            values.put("waybillNum",str_waybillNum);
            values.put("name",str_name);
            values.put("phone",str_phone);
            values.put("status",str_status);

            long newRowId = sqlitedb.insert(tableName, null, values);

            sqlitedb.close();
            dbHelper.close();

            if (newRowId != -1){

                TextView tv_waybillnum = (TextView) findViewById(R.id.waybillNum);
                TextView tv_name = (TextView) findViewById(R.id.name);
                TextView tv_status = (TextView) findViewById(R.id.status);
                TextView tv_phone = (TextView) findViewById(R.id.phone);

                tv_name.append(" : " + str_name);
                tv_phone.append(" : " + str_phone);
                tv_status.append(" : " + str_status);
                tv_waybillnum.append(" : " + str_waybillNum);
            }else {
                Toast.makeText(this, "등록실패 ",Toast.LENGTH_LONG).show();
            }
        }catch (SQLiteException e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
