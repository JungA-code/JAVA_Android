package com.example.workproject;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;



public class DBHelper extends SQLiteOpenHelper {

        public static final String tableName = "deliverty";

        public DBHelper(Context context, String waybillNum,SQLiteDatabase.CursorFactory factory, int version) {

            super(context, waybillNum ,factory ,version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table deliverty (product text ,waybillNum text, name text, phone text, status text)");

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            //버전이 업그레이드 됐을 경우 작업할 내용을 작성합니다.
        }



    }

