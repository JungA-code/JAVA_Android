package com.example.workproject;


import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImageAdapter extends BaseAdapter {

    private ArrayList<ListViewItem> mData;
    private Map<String, Integer> mDataProductMap;
    private Map<String, Integer> mDataCallMap;

    public ImageAdapter(ArrayList<ListViewItem> data){
        this.mData = data;
        mDataProductMap = new HashMap<>();
        mDataProductMap.put("생필품",R.drawable.product1);
        mDataProductMap.put("의류",R.drawable.product2);
        mDataProductMap.put("잡화",R.drawable.product3);
        mDataProductMap.put("취급주의",R.drawable.product4);
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent,false);

        ImageView product_image = convertView.findViewById(R.id.product);
        TextView waybillNum = convertView.findViewById(R.id.waybillNum);
        TextView name = convertView.findViewById(R.id.name);
        TextView phone = convertView.findViewById(R.id.phone);
        TextView status = convertView.findViewById(R.id.status);
        ImageView call = convertView.findViewById(R.id.call);

        ListViewItem item = mData.get(position);

        waybillNum.setText(item.getWaybillNum());
        name.setText(item.getName());
        phone.setText(item.getPhone());
        status.setText(item.getStatus());


        product_image.setImageResource(mDataProductMap.get(item.getProduct()));

        call.setImageResource(R.drawable.call);

        return convertView;
    }

}




