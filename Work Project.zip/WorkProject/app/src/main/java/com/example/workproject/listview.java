package com.example.workproject;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class listview extends AppCompatActivity {

    SQLiteDatabase sqlitedb;
    DBHelper dbHelper;

    ArrayList<ListViewItem> data;

    private Map<String, Integer> product_ImageMap;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nonmem_deliverty);

        // 데이터 준비
        initData();


        // 어뎁터
        ImageAdapter adapter = new ImageAdapter(data);


        //뷰
        ListView listView = findViewById(R.id.listview1);
        listView.setAdapter(adapter);

        //클릭
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });

    }

    public void initData() {
        try {

            dbHelper = new DBHelper(this, DBHelper.tableName, null, 1);

            sqlitedb = dbHelper.getReadableDatabase();

            Cursor cursor;
            cursor = sqlitedb.query("deliverty", null, null, null, null, null, null);

            while (cursor.moveToNext()) {
                String product_str = cursor.getString(cursor.getColumnIndex("product"));
                String waybillNum_str = cursor.getString(cursor.getColumnIndex("waybillNum"));
                String name_str = cursor.getString(cursor.getColumnIndex("name"));
                String phone_str = cursor.getString(cursor.getColumnIndex("phone"));
                String status_str = cursor.getString(cursor.getColumnIndex("status"));

                final int db = Log.i("db", product_str + waybillNum_str + name_str + phone_str + status_str);

                data  = new ArrayList<>();
                ListViewItem item = new ListViewItem();
                LinearLayout layout_list = new LinearLayout(this);
                layout_list.setOrientation(LinearLayout.VERTICAL);

                ImageView productimage = null;

                product_ImageMap = new HashMap<>();

                product_ImageMap.put("생필품",R.drawable.product1);
                product_ImageMap.put("의류",R.drawable.product2);
                product_ImageMap.put("잡화",R.drawable.product3);
                product_ImageMap.put("취급주의",R.drawable.product4);

                if(product_str.equals("생필품")){
                    productimage.setImageResource(product_ImageMap.get(item.getProduct()));
                }
                else if(product_str.equals("잡화")){
                    productimage.setImageResource(product_ImageMap.get(item.getProduct()));
                    }
                else if(product_str.equals("의류")) {
                    productimage.setImageResource(product_ImageMap.get(item.getProduct()));
                }
                else if(product_str.equals("취급주의")){
                        productimage.setImageResource(product_ImageMap.get(item.getProduct()));
                }



                ImageView productImage = new ImageView(this);
               // productImage.setImageResource(R.drawable.product1);


                TextView waybill = new TextView(this);
                waybill.setText(waybillNum_str);
                layout_list.addView(waybill);

                TextView name = new TextView(this);
                name.setText(name_str);
                layout_list.addView(name);


                TextView phone = new TextView(this);
                phone.setText(phone_str);
                layout_list.addView(phone);


                TextView status = new TextView(this);
                status.setText(status_str);
                layout_list.addView(status);


                ImageView call = new ImageView(this);
                call.setImageResource(R.drawable.call);


                item.setProduct(productimage);
                item.setData(waybillNum_str, productimage, name_str, phone_str, status_str, call);
                data.add(item);
            }

            cursor.close();
            sqlitedb.close();
            dbHelper.close();
        } catch (Exception e) {

        }
    }
}