package com.example.workproject;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.TextView;

public class ListViewItem {

    private ImageView product;
    private String waybillNum;
    private String name;
    private String phone;
    private String status;
    private ImageView call;


    public String getWaybillNum() {
        return waybillNum;
    }

    public void setWaybillNum(String waybillNum) {
        this.waybillNum = waybillNum;
    }


    public ImageView getProduct() {
        return product;
    }

    public void setProduct(ImageView product) {
        this.product = product;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ImageView getCall() {
        return call;
    }

    public void setCall(ImageView call) {
        this.call = call;
    }

    public void setData(String waybillNum, ImageView product, String name, String phone, String status, ImageView call){
        this.waybillNum = waybillNum;
        this.product = product;
        this.name = name;
        this.phone = phone;
        this.status = status;
        this.call = call;
    }
}
