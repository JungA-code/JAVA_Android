package com.example.workproject;

import android.content.Intent;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import static android.R.layout.*;

public class InsertDeliverty extends AppCompatActivity {

    Button insertBtn;
    Spinner spinner;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insert_form);
        setTitle("운송장 등록 ");

       spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter adapter
                = ArrayAdapter.createFromResource(this, R.array.number, simple_spinner_item);

       // adapter.setDropDownViewResource(activity_list_item);

        spinner.setAdapter(adapter);

        insertBtn = (Button) findViewById(R.id.insert);

        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText et_waybill = (EditText) findViewById(R.id.waybillNum);
                EditText et_name = (EditText) findViewById(R.id.name);
                EditText et_phone = (EditText) findViewById(R.id.phone);

                String str_waybill = et_waybill.getText().toString();
                String str_name = et_name.getText().toString();
                String str_phone = et_phone.getText().toString();

                RadioGroup rg_status = (RadioGroup)findViewById(R.id.radiogroup_status);
                RadioButton rg_status1 = (RadioButton) findViewById(R.id.status1);
                RadioButton rg_status2 = (RadioButton) findViewById(R.id.status2);
                RadioButton rg_status3 = (RadioButton) findViewById(R.id.status3);
                RadioButton rg_status4 = (RadioButton) findViewById(R.id.status4);
                String str_status = "";

                if(rg_status.getCheckedRadioButtonId() == R.id.status1){
                    str_status = rg_status1.getText().toString();
                }else if(rg_status.getCheckedRadioButtonId() == R.id.status2){
                    str_status = rg_status2.getText().toString();
                }else if
                (rg_status.getCheckedRadioButtonId() == R.id.status3){
                    str_status = rg_status3.getText().toString();
                }else{
                    str_status = rg_status4.getText().toString();
                }

                String str_product = spinner.getSelectedItem().toString();

                Intent it = new Intent(getApplicationContext(), RegisterCourier.class);

                it.putExtra("it_waybillnum", str_waybill);
                it.putExtra("it_name", str_name);
                it.putExtra("it_phone", str_phone);
                it.putExtra("it_status", str_status);
                it.putExtra("it_product",str_product);
                startActivity(it);

            }
        });

    }

    }




